/* ============================================================
   WISE-CITY-RP Launcher | Main Script
   ============================================================ */

(function() {
    'use strict';

    // ============================================================
    // الإعدادات الافتراضية
    // ============================================================
    const DEFAULTS = {
        ip: '127.0.0.1',
        port: '7777',
        discord: 'https://discord.gg/AwZxfNEM5',
        website: 'https://wise-city-rp.com',
        gamePackage: 'com.rockstargames.gtasa'   // حزمة اللعبة (SA-MP)
    };

    const STORAGE_KEYS = {
        nickname: 'wc_nickname',
        ip: 'wc_ip',
        port: 'wc_port',
        discord: 'wc_discord',
        website: 'wc_website'
    };

    // ============================================================
    // الحالة الحالية
    // ============================================================
    const state = {
        nickname: '',
        ip: DEFAULTS.ip,
        port: DEFAULTS.port,
        discord: DEFAULTS.discord,
        website: DEFAULTS.website
    };

    // ============================================================
    // عناصر DOM
    // ============================================================
    const $ = (id) => document.getElementById(id);

    const els = {
        splash:          $('splashScreen'),
        app:             $('appContainer'),
        nicknameInput:   $('nicknameInput'),
        ipInput:         $('ipInput'),
        portInput:       $('portInput'),
        connectBtn:      $('connectBtn'),
        connectStatus:   $('connectStatus'),
        launchGameBtn:   $('launchGameBtn'),
        onlineCount:     $('onlineCount'),
        uptimeValue:     $('uptimeValue'),
        toast:           $('toast'),
        // settings modal
        settingsIp:      $('settingsIp'),
        settingsPort:    $('settingsPort'),
        settingsDiscord: $('settingsDiscord'),
        settingsWebsite: $('settingsWebsite'),
        saveSettingsBtn: $('saveSettingsBtn'),
        // modals
        modalRules:      $('modalRules'),
        modalSettings:   $('modalSettings'),
        appVersion:      $('appVersion')
    };

    // ============================================================
    // إدارة التخزين المحلي (localStorage)
    // ============================================================
    const storage = {
        get(key, fallback = null) {
            try {
                return localStorage.getItem(key) ?? fallback;
            } catch (e) {
                return fallback;
            }
        },
        set(key, value) {
            try {
                localStorage.setItem(key, value);
            } catch (e) {
                console.warn('Storage error:', e);
            }
        }
    };

    // ============================================================
    // تحميل الإعدادات المحفوظة
    // ============================================================
    function loadSavedData() {
        state.nickname = storage.get(STORAGE_KEYS.nickname, '');
        state.ip       = storage.get(STORAGE_KEYS.ip, DEFAULTS.ip);
        state.port     = storage.get(STORAGE_KEYS.port, DEFAULTS.port);
        state.discord  = storage.get(STORAGE_KEYS.discord, DEFAULTS.discord);
        state.website  = storage.get(STORAGE_KEYS.website, DEFAULTS.website);

        // تحديث الواجهة
        els.nicknameInput.value = state.nickname;
        els.ipInput.value       = state.ip;
        els.portInput.value     = state.port;

        // تحديث الإعدادات في النافذة
        els.settingsIp.value      = state.ip;
        els.settingsPort.value    = state.port;
        els.settingsDiscord.value = state.discord;
        els.settingsWebsite.value = state.website;

        // تحديث أزرار الروابط
        updateLinkButtons();
    }

    // ============================================================
    // حفظ الإعدادات
    // ============================================================
    function saveSettings() {
        state.ip       = els.settingsIp.value.trim() || DEFAULTS.ip;
        state.port     = els.settingsPort.value.trim() || DEFAULTS.port;
        state.discord  = els.settingsDiscord.value.trim() || DEFAULTS.discord;
        state.website  = els.settingsWebsite.value.trim() || DEFAULTS.website;

        storage.set(STORAGE_KEYS.ip, state.ip);
        storage.set(STORAGE_KEYS.port, state.port);
        storage.set(STORAGE_KEYS.discord, state.discord);
        storage.set(STORAGE_KEYS.website, state.website);

        // تحديث الواجهة
        els.ipInput.value   = state.ip;
        els.portInput.value = state.port;

        updateLinkButtons();
        showToast('✅ تم حفظ الإعدادات بنجاح', 'success');
        closeModal('modalSettings');
    }

    // ============================================================
    // تحديث أزرار الروابط
    // ============================================================
    function updateLinkButtons() {
        document.querySelectorAll('.action-btn[data-url]').forEach(btn => {
            if (btn.classList.contains('discord')) {
                btn.dataset.url = state.discord;
            } else if (btn.classList.contains('website')) {
                btn.dataset.url = state.website;
            }
        });
    }

    // ============================================================
    // عرض Toast
    // ============================================================
    let toastTimer = null;
    function showToast(message, type = '') {
        els.toast.textContent = message;
        els.toast.className = 'toast show ' + type;

        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => {
            els.toast.className = 'toast ' + type;
        }, 2500);
    }

    // ============================================================
    // فتح/إغلاق النافذة المنبثقة
    // ============================================================
    function openModal(modalId) {
        const modal = $(modalId);
        if (modal) modal.classList.add('active');
    }

    function closeModal(modalId) {
        const modal = $(modalId);
        if (modal) modal.classList.remove('active');
    }

    // ============================================================
    // التحقق من صحة اسم اللاعب
    // ============================================================
    function validateNickname(nick) {
        if (!nick || nick.length < 3) {
            return { valid: false, error: 'اسم اللاعب قصير جداً (3 أحرف على الأقل)' };
        }
        if (nick.length > 24) {
            return { valid: false, error: 'اسم اللاعب طويل جداً (24 حرف كحد أقصى)' };
        }
        if (!/^[A-Za-z0-9_\[\]]+$/.test(nick)) {
            return { valid: false, error: 'الاسم يحتوي على رموز غير مسموحة' };
        }
        return { valid: true };
    }

    // ============================================================
    // منطق زر الاتصال
    // ============================================================
    function handleConnect() {
        const nickname = els.nicknameInput.value.trim();

        // التحقق
        const validation = validateNickname(nickname);
        if (!validation.valid) {
            showToast('❌ ' + validation.error, 'error');
            els.nicknameInput.focus();
            return;
        }

        // حفظ الاسم
        state.nickname = nickname;
        storage.set(STORAGE_KEYS.nickname, nickname);

        // إظهار حالة الاتصال
        els.connectStatus.textContent = 'جاري الاتصال بالسيرفر...';
        els.connectStatus.className = 'connect-status';

        // بناء رابط الاتصال
        const connectUrl = buildConnectUrl(state.ip, state.port, nickname);

        // محاولة الاتصال
        setTimeout(() => {
            const success = tryOpenGame(connectUrl);

            if (success) {
                els.connectStatus.textContent = `✅ جاري فتح اللعبة...`;
                els.connectStatus.className = 'connect-status success';
                showToast('🚀 يتم فتح اللعبة الآن', 'success');
            } else {
                // بديل: عرض نافذة تعليمات
                els.connectStatus.textContent = `⚠️ لم يتم العثور على اللعبة`;
                els.connectStatus.className = 'connect-status error';
                showToast('⚠️ اللعبة غير مثبتة على الجهاز', 'error');
                showLaunchInstructions(nickname, state.ip, state.port);
            }
        }, 800);
    }

    // ============================================================
    // بناء رابط الاتصال
    // ============================================================
    function buildConnectUrl(ip, port, nickname) {
        // صيغة sa-mp://IP:PORT
        const encodedNick = encodeURIComponent(nickname);
        return `samp://${ip}:${port}?nickname=${encodedNick}`;
    }

    // ============================================================
    // محاولة فتح اللعبة (يدعم SA-MP و open.mp)
    // ============================================================
    function tryOpenGame(url) {
        try {
            // محاولة فتح SA-MP
            const iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            iframe.src = url;
            document.body.appendChild(iframe);

            setTimeout(() => {
                document.body.removeChild(iframe);
            }, 2000);

            return true;
        } catch (e) {
            console.error('Connect error:', e);
            return false;
        }
    }

    // ============================================================
    // عرض تعليمات التشغيل يدوياً
    // ============================================================
    function showLaunchInstructions(nickname, ip, port) {
        const instructions = `
            <div style="text-align:center; padding: 10px;">
                <p style="color: var(--color-gold); font-weight: 700; margin-bottom: 16px;">
                    اتبع الخطوات التالية:
                </p>
                <div style="text-align: right; background: var(--color-bg-alt); padding: 14px; border-radius: 10px; margin-bottom: 10px;">
                    <p style="margin-bottom: 8px; color: var(--color-text-dim); font-size: 13px;">1. افتح لعبة SA-MP</p>
                    <p style="margin-bottom: 8px; color: var(--color-text-dim); font-size: 13px;">2. اضغط على Add Server</p>
                    <p style="margin-bottom: 8px; color: var(--color-text-dim); font-size: 13px;">3. أدخل المعلومات:</p>
                    <p style="margin-bottom: 4px; color: var(--color-cyan); font-family: monospace; font-size: 14px;">
                        <b>IP:</b> ${ip}
                    </p>
                    <p style="margin-bottom: 4px; color: var(--color-cyan); font-family: monospace; font-size: 14px;">
                        <b>Port:</b> ${port}
                    </p>
                    <p style="color: var(--color-gold); font-family: monospace; font-size: 14px;">
                        <b>Nickname:</b> ${nickname}
                    </p>
                </div>
                <p style="color: var(--color-text-dim); font-size: 12px;">
                    💡 يمكنك النسخ من الإعدادات
                </p>
            </div>
        `;

        // استخدام نافذة القوانين كقاعدة لعرض التعليمات
        const modal = els.modalRules;
        const title = modal.querySelector('.modal-header h3');
        const body = modal.querySelector('.modal-body');

        const originalTitle = title.innerHTML;
        const originalBody = body.innerHTML;

        title.innerHTML = '📥 كيفية الاتصال';
        body.innerHTML = instructions;
        modal.classList.add('active');

        // إعادة المحتوى عند الإغلاق
        const resetModal = () => {
            title.innerHTML = originalTitle;
            body.innerHTML = originalBody;
            modal.removeEventListener('click', resetModal);
        };
        setTimeout(() => modal.addEventListener('click', (e) => {
            if (e.target === modal || e.target.classList.contains('modal-close')) {
                resetModal();
            }
        }), 100);
    }

    // ============================================================
    // معالجة أزرار الروابط
    // ============================================================
    function handleActionButton(btn) {
        const url = btn.dataset.url;
        const action = btn.dataset.action;

        if (url) {
            // فتح الرابط في المتصفح الخارجي
            window.open(url, '_blank', 'noopener');
            showToast('🌐 جاري فتح الرابط...', 'success');
            return;
        }

        if (action === 'showRules') {
            openModal('modalRules');
            return;
        }

        if (action === 'showSettings') {
            openModal('modalSettings');
            return;
        }
    }

    // ============================================================
    // زر فتح اللعبة مباشرة
    // ============================================================
    function handleLaunchGame() {
        try {
            // محاولة فتح تطبيق اللعبة مباشرة
            window.location.href = 'samp://';
            showToast('🎯 جاري فتح اللعبة...', 'success');
        } catch (e) {
            showToast('⚠️ اللعبة غير مثبتة على الجهاز', 'error');
        }
    }

    // ============================================================
    // حفظ الاسم تلقائياً عند الكتابة
    // ============================================================
    let saveNickTimer = null;
    function handleNicknameChange() {
        clearTimeout(saveNickTimer);
        saveNickTimer = setTimeout(() => {
            const nick = els.nicknameInput.value.trim();
            if (nick.length >= 3) {
                storage.set(STORAGE_KEYS.nickname, nick);
                state.nickname = nick;
            }
        }, 500);
    }

    // ============================================================
    // محاكاة عدد اللاعبين ومدة التشغيل
    // (يمكن ربطها بـ API خارجي لاحقاً)
    // ============================================================
    function startStatsUpdater() {
        let online = 0;
        let uptimeSeconds = 0;

        // قيمة ابتدائية
        online = Math.floor(Math.random() * 40) + 20;

        setInterval(() => {
            // تحديث بسيط للمحاكاة
            online = Math.max(15, online + Math.floor(Math.random() * 5) - 2);
            els.onlineCount.textContent = online;

            uptimeSeconds++;
            const hours = Math.floor(uptimeSeconds / 3600);
            const mins = Math.floor((uptimeSeconds % 3600) / 60);
            els.uptimeValue.textContent = `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
        }, 1000);

        els.onlineCount.textContent = online;
    }

    // ============================================================
    // ربط جميع الأحداث
    // ============================================================
    function bindEvents() {
        // زر الاتصال
        els.connectBtn.addEventListener('click', handleConnect);

        // حفظ الاسم تلقائياً
        els.nicknameInput.addEventListener('input', handleNicknameChange);

        // أزرار الروابط السريعة
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('click', () => handleActionButton(btn));
        });

        // زر فتح اللعبة
        els.launchGameBtn.addEventListener('click', handleLaunchGame);

        // زر حفظ الإعدادات
        els.saveSettingsBtn.addEventListener('click', saveSettings);

        // أزرار إغلاق النوافذ المنبثقة
        document.querySelectorAll('[data-close]').forEach(btn => {
            btn.addEventListener('click', () => {
                closeModal(btn.dataset.close);
            });
        });

        // إغلاق النافذة عند النقر على الخلفية
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                }
            });
        });

        // منع إرسال النموذج بـ Enter
        els.nicknameInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                handleConnect();
            }
        });
    }

    // ============================================================
    // إخفاء شاشة التحميل وإظهار التطبيق
    // ============================================================
    function revealApp() {
        setTimeout(() => {
            els.splash.classList.add('hidden');
            els.app.classList.add('visible');
        }, 2200);
    }

    // ============================================================
    // التهيئة الرئيسية
    // ============================================================
    function init() {
        console.log('%cWISE-CITY-RP Launcher v1.0.0', 'color: #FFD700; font-size: 16px; font-weight: bold;');
        console.log('%cDeveloper: Mr walid', 'color: #00D9FF; font-size: 12px;');

        loadSavedData();
        bindEvents();
        startStatsUpdater();
        revealApp();
    }

    // ============================================================
    // تشغيل التطبيق عند جاهزية DOM
    // ============================================================
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();